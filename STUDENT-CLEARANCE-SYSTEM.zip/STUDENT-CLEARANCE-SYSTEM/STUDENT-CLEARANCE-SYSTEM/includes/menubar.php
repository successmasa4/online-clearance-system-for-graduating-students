<section class="menu-section">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="navbar-collapse collapse ">
                        <ul id="menu-top" class="nav navbar-nav navbar-right">
                            <li><a href="my-profile.php">My Profile</a></li>
                            <li><a href="contactus.html">Contact Us</a></li>
                            <li><a href="aboutus.html">About</a></li>
                             <li><a href="change-password.php">Change password  </a></li>
                            <li><a href="logout.php">Logout</a></li>
                            <li><a class="navbar-brand" href="index.php"><i class="fas fa-backward"></i> Back</a></li>

                        </ul>
                    </div>
                </div>

            </div>
        </div>
    </section>