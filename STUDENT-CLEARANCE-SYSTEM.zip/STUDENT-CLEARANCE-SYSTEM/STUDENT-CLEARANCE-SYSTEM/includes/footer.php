<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; ZU Online clearance
                </div>

            </div>
        </div>
    </footer>

    <style> .col-md-12{text-align: center;} </style>
